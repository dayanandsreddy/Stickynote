<?php
session_start();
if(!isset($_SESSION['user_details']))
{ ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Log In Form</title>
        <?php include 'links.php' ?>
    </head>
    <body>
    <!-- main -->
    <div class="main-w3layouts wrapper">
        <h1>Log In Form</h1>
        <div class="main-agileinfo">
            <div class="agileits-top">
                <form action="#" method="post" id="user-login-form">
                    <input class="text" type="email" name="email" placeholder="Email" required="">
                    <input class="text w3lpass" type="password" name="password" placeholder="Password" required="">
                    <input type="submit" value="Log In">
                </form>
                <p>Don't have an Account? <a href="createaccount.php"> Create Account Now!</a></p>
            </div>
        </div>
        <ul class="colorlib-bubbles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </div>
    <!-- //main -->
    </body>
    </html>
<?php }else{
    header("Location: homepage.php");
}
?>

