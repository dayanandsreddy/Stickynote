<?php

include ('data/config.php');
include ('data/StickyNotes.php');
session_start();
if(!isset($_SESSION['user_details']))
{
    header("Location: login.php");
}else{
    $userData = $_SESSION['user_details'];
    $stickyNotes = new StickyNotes();
    $notesCollectionData = $stickyNotes->getAllUserStickyNotes($db,$userData['id']);
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Log In Form</title>
        <?php include 'links.php' ?>
    </head>
    <body>
    <div class="header-block">
        <div class="header-wrap">
            <div class="create-new">
                <p class="create-new-note">Create New Note</p>
            </div>
            <div class="user-action">
                <div class="user-name">
                    <p>Hello <?php  echo $userData['user_name'] ?></p>
                </div>
                <div class="logout">
                    <a href="logout.php">Log Out</a>
                </div>

            </div>
        </div>

    </div>
    <!-- main -->
    <div class="main-w3layouts wrapper">
        <h1>Your Sticky Notes</h1>
        <?php
        if($notesCollectionData != null){ ?>
            <div class="sticky-notes">
                <ul>
                    <?php
                    foreach ($notesCollectionData as $note){ ?>
                        <li>
                            <a href="#" class="note-change-data" data-content='<?php echo json_encode($note) ?>' title="Click To Change Data">
                                <h2><?php echo $note['heading'] ?></h2>
                                <p><?php echo $note['content'] ?></p>
                            </a>
                        </li>
                <?php    }
                    ?>

                </ul>
            </div>
      <?php  }
        ?>
        <ul class="colorlib-bubbles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </div>

    <div id="create-new-note-model" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Create New Note</h4>
                </div>
                <div class="modal-body">
                    <div class="model-form-div">
                        <div class="agileits-top">
                            <form action="#" method="post" id="create-new-note-form">
                                <input type="hidden" name="user_id" value="<?php echo $userData['id'] ?>">
                                <input class="text" type="text" name="note_head" placeholder="Enter Note Heading" required="">
                                <textarea class="text w3lpass" name="note_content" placeholder="Enter Content" required=""></textarea>
                                <input type="submit" value="Create New">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <div id="update-note-model" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Update Note</h4>
                </div>
                <div class="modal-body">
                    <div class="model-form-div">
                        <div class="agileits-top">
                            <form action="#" method="post" id="update-note-form">
                                <input type="hidden" id="update_id" name="id" value="">
                                <input class="text" id="update_head" type="text" name="note_head" placeholder="Enter Note Heading" required="">
                                <textarea class="text w3lpass" id="update_content" name="note_content" placeholder="Enter Content" required=""></textarea>
                                <input type="submit" value="Update Note">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    </body>
    </html>

<?php }
?>

