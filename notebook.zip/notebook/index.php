<?php
session_start();
if(!isset($_SESSION['user_details']))
{
    header("Location: login.php");
}else{
    header("Location: homepage.php");
}