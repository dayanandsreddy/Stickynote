
CREATE TABLE `users` (
  `id` int(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_name` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_password` varchar(100) NOT NULL
);

CREATE TABLE `sticky_notes` (
  `id` int(100) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` int(10) NOT NULL,
  `heading` varchar(1000) NOT NULL,
  `content` varchar(10000) NOT NULL
);
