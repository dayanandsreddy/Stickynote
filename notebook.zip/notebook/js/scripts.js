
$(document).ready(function () {
    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": true,
        "progressBar": false,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "2000",
        "timeOut": "5000",
        "extendedTimeOut": "2000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };


    $('#user-create-account-form').submit(function (e) {
        e.preventDefault();
        var _form = $(this);

        $.ajax({
            url: "data/createaccount.php",
            type: "POST",
            data: _form.serialize(),
            success: function (data) {
                var decode = JSON.parse(data);
                if(decode.code == 200){
                    toastr.success(decode.message, "");
                    window.location = 'login.php';
                } else{
                    toastr.error(decode.message, "");
                }
            }
        });

    });

    $('#user-login-form').submit(function (e) {
        e.preventDefault();
        var _form = $(this);

        $.ajax({
            url: "data/login.php",
            type: "POST",
            data: _form.serialize(),
            success: function (data) {
                var decode = JSON.parse(data);
                if(decode.code == 200){
                    toastr.success(decode.message, "");
                    window.location = 'index.php';
                }else{
                    toastr.error(decode.message, "");
                }
            }
        });

    });

    $('#create-new-note-form').submit(function (e) {
        e.preventDefault();
        var _form = $(this);

        $.ajax({
            url: "data/createNote.php",
            type: "POST",
            data: _form.serialize(),
            success: function (data) {
                var decode = JSON.parse(data);
                if(decode.code == 200){
                    toastr.success(decode.message, "");
                    window.location = 'index.php';

                }
            }
        });

    });

    $('a.note-change-data').click(function () {
        var _self = $(this);
        var data = $(_self).data('content');
        $('#update_id').val(data.id);
        $('#update_head').val(data.heading);
        $('#update_content').val(data.content);
        $("#update-note-model").modal('show');
    });

    $('#update-note-form').submit(function (e) {
        e.preventDefault();
        var _form = $(this);

        $.ajax({
            url: "data/updateNote.php",
            type: "POST",
            data: _form.serialize(),
            success: function (data) {
                var decode = JSON.parse(data);
                if(decode.code == 200){
                    toastr.success(decode.message, "");
                    window.location = 'index.php';
                }
            }
        });

    });
    
    $('.create-new-note').click(function () {
        $("#create-new-note-model").modal('show');
    });

});