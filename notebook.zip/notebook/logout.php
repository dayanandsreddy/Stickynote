<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 20/11/18
 * Time: 11:17 PM
 */

session_start();
if(session_destroy()) {
    header("Location: login.php");
}